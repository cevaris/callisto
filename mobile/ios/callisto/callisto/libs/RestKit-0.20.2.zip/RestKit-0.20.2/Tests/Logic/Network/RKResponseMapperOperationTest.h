//
//  RKResponseMapperOperationTest.h
//  RestKit
//
//  Created by Blake Watters on 10/5/12.
//  Copyright (c) 2012 RestKit. All rights reserved.
//

#import "RKTestEnvironment.h"

@interface RKResponseMapperOperationTest : RKTestCase

@end
