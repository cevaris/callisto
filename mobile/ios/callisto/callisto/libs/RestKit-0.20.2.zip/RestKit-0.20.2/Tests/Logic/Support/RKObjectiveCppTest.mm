//
//  RKObjectiveCppTest.mm
//  RestKit
//
//  Created by Blake Watters on 4/11/12.
//  Copyright (c) 2012 RestKit. All rights reserved.
//

#import "RKTestEnvironment.h"

@interface RKObjectiveCppTest : RKTestCase

@end

@implementation RKObjectiveCppTest

- (void)testCompiles
{
    // Nothing to do.
}

@end