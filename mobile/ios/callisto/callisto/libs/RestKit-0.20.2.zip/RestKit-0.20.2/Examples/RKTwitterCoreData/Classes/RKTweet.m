//
//  RKTweet.m
//  RKTwitter
//
//  Created by Blake Watters on 9/5/10.
//  Copyright (c) 2009-2012 RestKit. All rights reserved.
//

#import "RKTweet.h"

@implementation RKTweet

@dynamic statusID;
@dynamic createdAt;
@dynamic text;
@dynamic urlString;
@dynamic inReplyToScreenName;
@dynamic isFavorited;
@dynamic user;

@end
